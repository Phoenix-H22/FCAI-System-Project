

<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-body">
      <!-- Button trigger modal -->
      <div class="margin-bottom">
      <a href="<?php echo e(route('faq.add')); ?>" class="btn btn-md btn-primary">+ Create FAQ</a>
        
      </div>

      <table class="table table-bordered" id="faqTable">
        <thead>
          <tr>
            <th>SN</th>
            <th>Title</th>
            <th>Details</th>
            <th>Action</i>
            </th>
          </tr>
        </thead>
        <?php if(isset($faqs)): ?>
        <tbody>

        </tbody>
        <?php endif; ?>
      </table>
    </div>
    

  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
  $(function () {

    var table = $('#faqTable').DataTable({
      processing: true,
      serverSide: true,
      responsive: true,
      autoWidth: false,
      scrollCollapse: true,


      ajax: "<?php echo e(route('faq.index')); ?>",
      columns: [

	      {data: 'DT_RowIndex', name: 'DT_RowIndex',orderable: false, searchable: false},
	      {data: 'title', name: 'title'},
	      {data: 'details', name: 'details'},
	      {data: 'action', name: 'action',searchable: false}

      ],
      dom : 'lBfrtip',
      buttons : [
      'csv','excel','pdf','print'
      ],
      order : [[0,'desc']]
    });

  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', [
  'page_header' => 'FAQ',
  'dash' => '',
  'quiz' => 'active',
  'users' => '',
  'questions' => '',
  'top_re' => '',
  'all_re' => '',
  'sett' => ''
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdalrhman M. Alkady\Documents\GitHub\FCAI-System-Project\resources\views/admin/faq/index.blade.php ENDPATH**/ ?>
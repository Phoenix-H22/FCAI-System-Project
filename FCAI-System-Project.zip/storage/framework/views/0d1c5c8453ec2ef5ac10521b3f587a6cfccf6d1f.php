

<?php $__env->startSection('content'); ?>
  <div class="content-block box">
    <div class="box-body table-responsive">
      <table id="topTable" class="table table-striped">
        <thead>
          <tr>
            <th>#</th>
            <th>Student Name</th>
            <th>Mobile No.</th>          
            <th>Quiz</th>
            <th>Total Question Marks</th>
            <th>Marks You Got</th>
            
          </tr>
        </thead>
        <tbody>
          <?php if($answers): ?>
            <?php $__currentLoopData = $filtStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php echo e($key+1); ?>

                </td>
                <td><?php echo e($student->name); ?></td>
                <td><?php echo e($student->mobile ? $student->mobile : '-'); ?></td>               
                <td><?php echo e($topic->title); ?></td>
                <td>
                  <?php echo e($c_que*$topic->per_q_mark); ?>

                </td>
                <td>
                  <?php
                    $mark = 0;
                    $correct = collect();
                  ?>
                  <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($answer->user_id == $student->id && $answer->answer == $answer->user_answer): ?>
                      <?php
                       $mark++;
                      ?>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    $correct = $mark*$topic->per_q_mark;
                  ?>
                  <?php echo e($correct); ?>

                </td>
                
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', [
  'page_header' => "Top Students / {$topic->title}",
  'dash' => '',
  'quiz' => '',
  'users' => '',
  'questions' => '',
  'top_re' => 'active',
  'all_re' => '',
  'sett' => ''
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdalrhman M. Alkady\Documents\GitHub\FCAI-System-Project\resources\views/admin/top_reports/show.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
  <div class="box">
    <div class="box-body">
      <div class="form-group<?php echo e($errors->has('css') ? ' has-error' : ''); ?>">
    <form action="<?php echo e(route('css.store')); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

    <label for="css">Custom CSS:</label>
    <small class="text-danger"><?php echo e($errors->first('css','CSS Cannot be blank !')); ?></small>
    <textarea placeholder="a {
      color:red;
    }" required id="he" class="form-control" name="css" rows="10" cols="30"><?php echo e($css_get); ?></textarea>
    <div style="margin-top: 15px;" >
      <input type="submit" value="ADD CSS" class="btn btn-md btn-primary">
    </div>
    </form>
    </div>
    <br>
    <div class="form-group<?php echo e($errors->has('js') ? ' has-error' : ''); ?>">
    <form action="<?php echo e(route('js.store')); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

    <label for="js">Custom JS:</label>
    <small class="text-danger"><?php echo e($errors->first('js','Javascript Cannot be blank !')); ?></small>
    <textarea required placeholder="$(document).ready(function{
      //code
  });" class="form-control" name="js" rows="10" cols="30"><?php echo e($js_get); ?></textarea>
    <div style="margin-top: 15px;" class="form-group">
      <input type="submit" value="ADD JS" class="btn btn-md btn-primary">
    </div>
    </form>
    </div>
  </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', [
  'page_header' => 'Custom Style Settings',
  'dash' => 'active',
  'quiz' => '',
  'users' => '',
  'questions' => '',
  'top_re' => '',
  'all_re' => '',
  'sett' => '',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdalrhman M. Alkady\Documents\GitHub\FCAI-System-Project\resources\views/admin/customstyle/add.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/ico" href="<?php echo e(asset('/images/logo/'. $setting->favicon)); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom-style.css')); ?>">
    <!--[if IE]>
    <link rel="shortcut icon" href="/favicon.ico" type="image/vnd.microsoft.icon">
    <![endif]-->

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title><?php echo e($setting->welcome_txt); ?></title>

    <!-- Styles -->
    <?php echo $__env->yieldContent('head'); ?>

</head>
<body>
    <div id="app" style="position: relative;">
        <?php echo $__env->yieldContent('top_bar'); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <br>
        <br>
    </div>
    <?php
     $ct = App\copyrighttext::where('id','=',1)->first();
    ?>
    
   <div class="front-footer">
        <div class="container" >
            <div class="row">
                <div class="col-md-6">
                    <?php echo e($ct->name); ?>

                </div>
                <div class="col-md-6">
                    <?php
                    $si = App\SocialIcons::all();
                    ?>
                    <?php $__currentLoopData = $si; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($s->status==1): ?>
                        <a target="_blank" title="Visit <?php echo e($s->title); ?>" href="<?php echo e($s->url); ?>"><img width="32px" src="<?php echo e(asset('images/socialicons/'.$s->icon)); ?>" alt="<?php echo e($s->title); ?>" title="<?php echo e($s->title); ?>" style="margin-top:-5px;z-index:9999;"></a>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom-js.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\Abdalrhman M. Alkady\Documents\GitHub\FCAI-System-Project\resources\views/layouts/app.blade.php ENDPATH**/ ?>
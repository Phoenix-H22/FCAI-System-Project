
<?php $__env->startSection('content'); ?>
<div class="box">
	<div class="box-body">
		<?php $__currentLoopData = $ct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form action="<?php echo e(route('copyright.update',$c->id)); ?>" method="POST" class="col-md-6">
		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('PUT')); ?>

		<div class="form-group <?php echo e($errors->has('copyright') ? 'has error' : ''); ?>">
			
		
		<label for="copy">Copyright:</label>
		<input type="text" value="<?php echo e($c ->name); ?>" name="name" class="form-control" placeholder="Enter Copyright Text">
		</div>
		<button type="submit" class="btn btn-primary btn-md"><i class="fa fa-save"></i> Save Setting</button>

	</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', [
  'page_header' => 'Copyright Text',
  'dash' => 'active',
  'quiz' => '',
  'users' => '',
  'questions' => '',
  'top_re' => '',
  'all_re' => '',
  'sett' => ''
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdalrhman M. Alkady\Documents\GitHub\FCAI-System-Project\resources\views/admin/copyright/index.blade.php ENDPATH**/ ?>
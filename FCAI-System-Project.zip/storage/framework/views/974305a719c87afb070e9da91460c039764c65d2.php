

<?php $__env->startSection('content'); ?>
  <div class="box">
    <div class="box-body">
        <h3>Edit Question
          <a href="<?php echo e(route('questions.show', $topic->id)); ?>" class="btn btn-gray pull-right">
            <i class="fa fa-arrow-left"></i> 
            <?php echo e(__('Back')); ?>

          </a>
        </h3>
      <hr>
       <?php echo Form::model($question, ['method' => 'PATCH', 'action' => ['QuestionsController@update', $question->id], 'files' => true]); ?>

                     
        <div class="row">
          <div class="col-md-4">
            <?php echo Form::hidden('topic_id', $topic->id); ?>

            <div class="form-group<?php echo e($errors->has('question') ? ' has-error' : ''); ?>">
              <?php echo Form::label('question', 'Question'); ?>

              <span class="required">*</span>
              <?php echo Form::textarea('question', null, ['class' => 'form-control', 'placeholder' => 'Please Enter Question', 'rows'=>'8', 'required' => 'required']); ?>

              <small class="text-danger"><?php echo e($errors->first('question')); ?></small>
            </div>
            <div class="form-group<?php echo e($errors->has('answer') ? ' has-error' : ''); ?>">
                <?php echo Form::label('answer', 'Correct Answer'); ?>

                <span class="required">*</span>
                <?php echo Form::select('answer', array('A'=>'A', 'B'=>'B', 'C'=>'C', 'D'=>'D','E'=>'E','F'=>'F'),null, ['class' => 'form-control select2', 'required' => 'required', 'placeholder'=>'']); ?>

                <small class="text-danger"><?php echo e($errors->first('answer')); ?></small>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group<?php echo e($errors->has('a') ? ' has-error' : ''); ?>">
              <?php echo Form::label('a', 'A - Option'); ?>

              <span class="required">*</span>
              <?php echo Form::text('a', null, ['class' => 'form-control', 'placeholder' => 'Please Enter A Option', 'required' => 'required']); ?>

              <small class="text-danger"><?php echo e($errors->first('a')); ?></small>
            </div>
            <div class="form-group<?php echo e($errors->has('b') ? ' has-error' : ''); ?>">
              <?php echo Form::label('b', 'B - Option'); ?>

              <span class="required">*</span>
              <?php echo Form::text('b', null, ['class' => 'form-control', 'placeholder' => 'Please Enter B Option', 'required' => 'required']); ?>

              <small class="text-danger"><?php echo e($errors->first('b')); ?></small>
            </div>
            <div class="form-group<?php echo e($errors->has('c') ? ' has-error' : ''); ?>">
              <?php echo Form::label('c', 'C - Option'); ?>

              <span class="required">*</span>
              <?php echo Form::text('c', null, ['class' => 'form-control', 'placeholder' => 'Please Enter C Option', 'required' => 'required']); ?>

              <small class="text-danger"><?php echo e($errors->first('c')); ?></small>
            </div>
            <div class="form-group<?php echo e($errors->has('d') ? ' has-error' : ''); ?>">
              <?php echo Form::label('d', 'D - Option'); ?>

              <span class="required">*</span>
              <?php echo Form::text('d', null, ['class' => 'form-control', 'placeholder' => 'Please Enter D Option', 'required' => 'required']); ?>

              <small class="text-danger"><?php echo e($errors->first('d')); ?></small>
            </div>

            <div class="form-group<?php echo e($errors->has('e') ? ' has-error' : ''); ?>">
              <?php echo Form::label('e', 'E - Option'); ?>

              <?php echo Form::text('e', null, ['class' => 'form-control', 'placeholder' => 'Please Enter E Option']); ?>

              <small class="text-danger"><?php echo e($errors->first('e')); ?></small>
            </div>

            <div class="form-group<?php echo e($errors->has('f') ? ' has-error' : ''); ?>">
              <?php echo Form::label('f', 'F - Option'); ?>

              <?php echo Form::text('f', null, ['class' => 'form-control', 'placeholder' => 'Please Enter F Option']); ?>

              <small class="text-danger"><?php echo e($errors->first('f')); ?></small>
            </div>

          </div>
          <div class="col-md-4">
            <div class="form-group<?php echo e($errors->has('code_snippet') ? ' has-error' : ''); ?>">
                <?php echo Form::label('code_snippet', 'Code Snippets'); ?>

                <?php echo Form::textarea('code_snippet', null, ['class' => 'form-control', 'placeholder' => 'Please Enter Code Snippets', 'rows' => '5']); ?>

                <small class="text-danger"><?php echo e($errors->first('code_snippet')); ?></small>
            </div>
            <div class="form-group<?php echo e($errors->has('answer_ex') ? ' has-error' : ''); ?>">
                <?php echo Form::label('answer_exp', 'Answer Explanation'); ?>

                <?php echo Form::textarea('answer_exp', null, ['class' => 'form-control',  'placeholder' => 'Please Enter Answer Explanation',  'rows' => '4']); ?>

                <small class="text-danger"><?php echo e($errors->first('answer_ex')); ?></small>
            </div>
          </div>
          <div class="col-md-12">
            <div class="extras-block">
              <h4 class="extras-heading">Images And Video For Question</h4>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group<?php echo e($errors->has('question_video_link') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('question_video_link', 'Add Video To Question'); ?>

                    <?php echo Form::text('question_video_link', null, ['class' => 'form-control', 'placeholder'=>'https://myvideolink.com/embed/..']); ?>

                    <small class="text-danger"><?php echo e($errors->first('question_video_link')); ?></small>
                    <p class="help">YouTube And Vimeo Video Support (Only Embed Code Link)</p>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group<?php echo e($errors->has('question_img') ? ' has-error' : ''); ?>">
                    <?php echo Form::label('question_img', 'Add Image In Question'); ?>

                    <?php echo Form::file('question_img'); ?>

                    <small class="text-danger"><?php echo e($errors->first('question_img')); ?></small>
                    <p class="help">Please Choose Only .JPG, .JPEG and .PNG</p>
                  </div>
                </div>

                <div class="col-md-6">
                  <label for="question_audio">Add Audio Explanation:</label>
                   <div class="form-group<?php echo e($errors->has('question_audio') ? ' has-error' : ''); ?>">
                      <input type="text" value="<?php echo e($question->question_audio); ?>" placeholder="http://" class="form-control" name="question_audio">
                   </div>
                   
                </div>
              </div>
            </div>
          </div>
        </div>
    
    
        <div class="btn-group pull-right">
          <?php echo Form::submit("Update", ['class' => 'btn btn-wave']); ?>

        </div>
    
    <?php echo Form::close(); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', [
  'page_header' => 'Question',
  'dash' => '',
  'quiz' => '',
  'users' => '',
  'questions' => 'active',
  'top_re' => '',
  'all_re' => '',
  'sett' => ''
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Abdalrhman M. Alkady\Documents\GitHub\FCAI-System-Project\resources\views/admin/questions/edit.blade.php ENDPATH**/ ?>